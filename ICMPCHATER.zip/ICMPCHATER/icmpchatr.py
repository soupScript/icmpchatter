from scapy.all import *
import socket
import threading
lastdest=""
def FilterOutEchos(pkt):
    if pkt.haslayer(ICMP):
        if pkt[ICMP].type!=8:
            return True
        else:
            return False
    else:
        return False

def listenIncoming():
    global lastdest
    while True:
        speak=sniff(filter=f"icmp and host {socket.gethostbyname(socket.gethostname())}", lfilter=FilterOutEchos, count=1)[0]
        print(f"Message from {speak.src}: {speak.load}")
        lastdest=speak.src
threading.Thread(target=listenIncoming).start()
while True:
    command=input()
    if command=="send":
        destination=input("Where to?: ")
        payld=input("Message?: ")
        packet=IP(dst=destination)/ICMP()/payld
        send(packet)
    if command=="reply":
        payld=input("Message?: ")
        packet=IP(dst=lastdest)/ICMP()/payld
        send(packet)
    if command=="savecontact":
        nametosave=input("New contact name?: ")
        iptosave=input("IP of contact?: ")
        with open("CONTACTSDONOTDELETE.txt", "a") as f:
            f.write(f"{nametosave}:{iptosave}:\n")
    if command=="sendc":
        destination=input("Contact?: ")
        with open("CONTACTSDONOTDELETE.txt", "r") as f:
            firststep=f.read()
            splitted=firststep.split(":")
            if destination in splitted:
                newdest=splitted[splitted.index(destination)+1]
                
        payld=input("Message?: ")
        packet=IP(dst=newdest)/ICMP()/payld
        send(packet)